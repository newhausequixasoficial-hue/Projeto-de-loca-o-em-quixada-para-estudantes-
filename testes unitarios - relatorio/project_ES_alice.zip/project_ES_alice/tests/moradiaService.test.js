const { validarVinculoAcademico, filtrarImoveis } = require('../src/moradiaService');

describe('Testes Unitários - Sistema de Moradia Universitária', () => {

  // Teste 1: RF02 - Sucesso no vínculo institucional
  test('CTU-01 (RF02): Deve aprovar cadastro com e-mail institucional da UFC ou UECE', () => {
    const usuarioUFC = { nome: 'Artur', email: 'artur@ufc.br' };
    const resultado = validarVinculoAcademico(usuarioUFC);

    expect(resultado.aprovado).toBe(true);
    expect(resultado.motivo).toBeNull();
  });

  // Teste 2: RF02 - Rejeição por e-mail não acadêmico
  test('CTU-02 (RF02): Deve rejeitar e-mail comum sem vínculo acadêmico', () => {
    const usuarioComum = { nome: 'João', email: 'joao@gmail.com' };
    const resultado = validarVinculoAcademico(usuarioComum);

    expect(resultado.aprovado).toBe(false);
    expect(resultado.motivo).toContain("E-mail institucional inválido");
  });

  // Teste 3: RF01/RF05 - Filtragem de catálogo por preço e perfil
  test('CTU-03 (RF05): Deve filtrar imóveis de acordo com preço máximo e estilo de vida', () => {
    const listaImoveis = [
      { id: 1, titulo: 'Quarto Silencioso Proximo UFC', preco: 450, estiloVida: 'silencioso' },
      { id: 2, titulo: 'República Barulhenta', preco: 350, estiloVida: 'festivo' },
      { id: 3, titulo: 'Apartamento Estudantil', preco: 800, estiloVida: 'silencioso' }
    ];

    const filtro = { precoMaximo: 500, estiloVida: 'silencioso' };
    const resultado = filtrarImoveis(listaImoveis, filtro);

    expect(resultado.length).toBe(1);
    expect(resultado[0].id).toBe(1);
  });

});
