module.exports = {
  e2e: {
    allowCypressEnv: false,
    supportFile: false,
    specPattern: "cypress/e2e/**/*.cy.{js,jsx,ts,tsx}",
    setupNodeEvents(on, config) {
      // listeners
    },
  },
};
