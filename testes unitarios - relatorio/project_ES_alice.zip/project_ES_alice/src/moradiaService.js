/**
 * Módulo de Negócio - Sistema de Moradia Universitária
 */

// RF02: Validar e confirmar o vínculo acadêmico (UFC, UECE, etc.)
function validarVinculoAcademico(usuario) {
  if (!usuario || !usuario.email) {
    throw new Error("Dados de usuário inválidos.");
  }

  const dominiosAceitos = ['ufc.br', 'alunos.uece.br', 'uece.br'];
  const dominioEmail = usuario.email.split('@')[1];

  if (!dominiosAceitos.includes(dominioEmail)) {
    return { 
      aprovado: false, 
      motivo: "E-mail institucional inválido. É necessário possuir vínculo com UFC ou UECE." 
    };
  }

  return { aprovado: true, motivo: null };
}

// RF01 e RF05: Filtrar catálogo de imóveis por preço e estilo de vida
function filtrarImoveis(imoveis, filtro) {
  if (!Array.isArray(imoveis)) return [];

  return imoveis.filter(imovel => {
    // Filtro por preço máximo (RF01)
    if (filtro.precoMaximo && imovel.preco > filtro.precoMaximo) {
      return false;
    }
    // Filtro por estilo de vida / perfil de estudo (RF05)
    if (filtro.estiloVida && imovel.estiloVida !== filtro.estiloVida) {
      return false;
    }
    return true;
  });
}

module.exports = {
  validarVinculoAcademico,
  filtrarImoveis
};
